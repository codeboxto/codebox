<?php

session_start();

if(isset($_POST['enter']))
{   
    $a_email = $_POST["admin_email"];
    $a_password = $_POST['admin_password'];
    

 include("../kidicite_config.php");
$sql= $kidicite_config->query("Select admin_name,admin_email,admin_password from admin where admin_email='$a_email' && admin_password='$a_password'  "); 

if (mysqli_num_rows($sql) > 0)
{
while($row = mysqli_fetch_assoc($sql))
{
$_SESSION['name']=$row['admin_name']; 
$_SESSION['email']=$row['admin_email'];      
$_SESSION['password']=$row['admin_password'];    
$name=$_SESSION['name'];       
$email=$_SESSION['email'];
$password= $_SESSION['password'];

}

header ("location:admin_home.php");
}

else 
{
    echo "<script>alert('Please Login Again'); window.location = 'admin_login.php';</script>";


}
}
			

	?>