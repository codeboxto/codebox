<?php
session_start();
$name=$_SESSION['name'];       
$email=$_SESSION['email'];
$password= $_SESSION['password'];
require("../kidicite_config.php");
$sql="Select admin_email,admin_password from admin where admin_email='$email' && admin_password='$password'";
$result= $kidicite_config->query($sql);
if(!$result)
{
    echo "Error updating record: " . $kidicite_config->error;
}


?>
<!doctype html>

<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Course Page</title>
    
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Register Course Data</h6>
                    <form action="course_data.php" method="post">
                        <div class="mb-3 text-start">
                            <label for="id" class="form-label">Course ID</label>
                            <input type="text" class="form-control" placeholder="Enter Courses ID" name="course_id" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Course Name</label>
                            <input type="text" class="form-control" placeholder="Course Name" name="course_name" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="status" class="form-label">Course Status</label>
                             <select name="course_status" class="form-select" required >
                            <option value="open">Open</option>
                            <option value="close">Close</option>
                            </select> 
                        </div>                      
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Register</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_course.php">Back To View Course</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>