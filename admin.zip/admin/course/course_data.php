<?php
if (isset($_POST["enter"]))
{
	include("../kidicite_config.php");
	$c_id=$_POST["course_id"];
	$c_name=$_POST["course_name"];
	$c_status=$_POST["course_status"];    
    
	$course_info_sql = "INSERT INTO course(course_id,course_name,course_status) 
	VALUES ('$c_id','$c_name','$c_status')";

    if ($kidicite_config->query($course_info_sql) === TRUE) {
       header ("location:view_course.php");
    } else {
        echo "Failed insert:".mysqli_connect_error($kidicite_config);

}
}
?>