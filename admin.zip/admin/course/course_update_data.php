<?php
require("../kidicite_config.php");

$c_id=$_POST['cid'];
$course_id=$_POST['course_id'];
$c_name=$_POST['course_name'];
$c_status=$_POST['course_status'];


	$update_result=mysqli_query($kidicite_config," UPDATE course SET  
	course_id='$course_id',
	course_name='$c_name',
    course_status='$c_status'
    WHERE c_id='$c_id'");
	if($update_result)
	{
	header('Location:view_course.php');
	}
else
	{
	echo "No Data";
	}
?>