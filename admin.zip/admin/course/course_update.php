<!doctype html>
<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Course Page</title>
    
</head>

<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <?php
$c_id = "";                    
$course_id = "";
$course_name = "";
$course_status = "";
require("../kidicite_config.php");
$c_id = isset($_GET['c_id'])? $_GET['c_id'] : "";
$course_id = isset($_GET['course_id'])? $_GET['course_id'] : "";
$course_name= isset($_GET['course_name'])? $_GET['course_name'] : "";
$course_status = isset($_GET['course_status'])? $_GET['course_status'] : "";

?>

                    <h6 class="mb-4 text-muted">Update Course Data</h6>
                    <form action="course_update_data.php" method="post">
                    <input type="hidden" class="form-control" value="<?php echo $c_id;?>"  name="cid" >
                        <div class="mb-3 text-start">
                            <label for="id" class="form-label">Course ID</label>
                            <input type="text" class="form-control" placeholder="Enter Courses ID" value="<?php echo $course_id;?>"  name="course_id" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Course Name</label>
                            <input type="text" class="form-control" placeholder="Course Name" value="<?php echo $course_name;?>"  name="course_name" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="status" class="form-label">Course Status</label>
                             <select name="course_status" value="<?php echo $course_status;?>" class="form-select" required>    
                            <option value="open">Open</option>
                            <option value="close">Close</option>
                            </select> 
                        </div>                      
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Update</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_course.php">Back To View Course</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>