<?php
session_start();
$name=$_SESSION['name'];       
$email=$_SESSION['email'];
$password= $_SESSION['password'];

?>

<!doctype html>
<html lang="en">

<head>
    <!--header-->
<?php include("../assets/header_links/header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Admin Home Page</title>
</head>

<body>
    <div class="wrapper">
        <!--slider navigation link-->
        <?php include("../assets/header_links/slider.php");?> 
        <!-- End of slider navigation link-->
        <div id="body" class="active">
            <!-- quick link navigation component -->
            <?php require("../assets/header_links/quick_links.php");?> 
            <!-- end of quick link navigation -->
            <div class="content">
                <div class="container">
                    <div class="page-title">
                        <h3>Course
                        </h3>
                    </div>
                    <!--create search box-->
                    <div class="search">
                    <input type="text" class="searchTerm" id="myInput" onkeyup="myFunction()" placeholder="Search Course ID"> 
                        </button>
                    </div>  
                    <!--end of creating search box-->
                <!-- To reate new course-->
                     <button class="create_new"><a href="course.php">Create New One</a></button>
               <!-- end of creating button-->
                    <div class="box box-primary">                
                        <div class="box-body">
                            <?php
                         include("../kidicite_config.php");   
              

               $sql=$kidicite_config->query("select * from course " ); 
               
                            
                         echo"<table width='100%' class='table table-hover' id='myTable'>
                                    <thead>
                                    <tr>
                                        <th>Course ID</th>
                                        <th>Course Name</th>
                                        <th>Course Status</th>
                                       
                                        <th>Action</th>
                                        
                                    </tr>
                                </thead>"  ; 
                                while($row=$sql->fetch_assoc())
                                {	
                    $c1=$row['c_id'];               
                    $c2=$row['course_id']; 
                    $c3=$row['course_name'];
				    $c4=$row['course_status'];
 
			
					echo "           <tbody>
                                    <tr>
                                        <td>$c2</td>
                                        <td>$c3</td>
                                        <td>$c4</td>

                                        <td>
                                            <a href=\"course_update.php? 
                                            c_id=$c1 &
                                            course_id=$c2 &
                                            course_name=$c3 &
                                            course_status=$c4\"
                                            
                                            class='btn btn-outline-info btn-rounded'><i class='fas fa-pen'></i></a>
                                            <a href='delete.php'/? class='btn btn-outline-danger btn-rounded'><i class='fas fa-trash'></i></a>
                                        </td>"
                    ;
                    
					 echo"
					 		 </tr>
                        
                                </tbody>"; 
					}
                    
                                   
                           	echo  "</table>";
                               
                                ?>
                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include("../assets/header_links/extra_links.php");?>
    <script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
</body>

</html>