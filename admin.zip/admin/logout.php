<!DOCTYPE html>
<html>
    <body>
   <?php
header ("location:index.php");
?>   
    </body>  
</html>
