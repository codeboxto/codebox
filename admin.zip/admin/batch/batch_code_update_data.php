<?php
$kidicite_config=mysqli_connect("localhost","root","","kidicite");

$batch_id=$_POST['batch_id'];
$batch_name=$_POST['batch_name'];
$start_date=$_POST['start_date'];
$end_date=$_POST['end_date'];
$class_detail_id=$_POST['class_detail_id'];


	$update_result=mysqli_query($kidicite_config," UPDATE batch_code SET  batch_name='$batch_name',
    start_date='$start_date',
    end_date='$end_date',    
    class_detail_id='$class_detail_id'
    WHERE batch_id='$batch_id'");
	if($update_result)
	{
	header('Location:view_batch_code.php');
	}
else
	{
	echo "No Data";
	}
?>