<?php include("header.php");?>
<nav id="sidebar" class="active">
            <div class="sidebar-header">
                <img src="../assets/img/logo_transparent.png" width="50px" height="50px" alt="bootraper logo" class="app-logo">
            </div>
            <ul class="list-unstyled components text-secondary">
                <li>
                    <a href="../authentication/admin_home.php"><i class="fas fa-home"></i> Home Page</a>
                </li>
                <li>
                    <a href="../student/view_student_data.php"><i class="fas fa-table"></i> Students</a>
                </li>
                <li>
                    <a href="#uielementsmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down">
                        <i class="fas fa-layer-group"></i> Click this link to insert data</a><ul class="collapse list-unstyled" id="uielementsmenu">
                        <li>
                            <a href="../course/view_course.php"><i class="fas fa-angle-right"></i> Course</a>
                        </li>
                        <li>
                            <a href="../class/view_class.php"><i class="fas fa-angle-right"></i> Class</a>
                        </li>
                        <li>
                            <a href="../class_detail/view_class_detail.php"><i class="fas fa-angle-right"></i> Class Details</a>
                        </li>
                        <li>
                            <a href="../batch/view_batch_code.php"><i class="fas fa-angle-right"></i>Batch </a>
                        </li>
                         <li>
                            <a href="../course_detail/view_course_detail.php"><i class="fas fa-angle-right"></i> Course Detail</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="users.html"><i class="fas fa-user-friends"></i>Staffs</a>
                </li>
                <li>
                    <a href="settings.html"><i class="fas fa-cog"></i>Settings</a>
                </li>
            </ul>
        </nav>