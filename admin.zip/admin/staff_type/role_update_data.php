<?php

require("../kidicite_config.php");

$id=$_POST['stype_id'];
$staff_type_id=$_POST['staff_type_id'];
$role=$_POST['role'];


	$update_result=mysqli_query($kidicite_config," UPDATE staff_type SET  staff_type_id='$staff_type_id',
    role='$role'
    WHERE id='$id'");
	if($update_result)
	{
	header('Location:view_role.php');
	}
else
	{
	echo "No Data";
	}
?>