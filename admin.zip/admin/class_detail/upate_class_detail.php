<?php
$kidicite_config=mysqli_connect("localhost","root","","kidicite");

$c_detail_id=$_POST['class_detail_id'];
$c_detail_name=$_POST['class_detail_name'];
$class_id=$_POST['class_id'];
$course_id=$_POST['course_id'];
$description=$_POST['description'];
$detail_status=$_POST['detail_status'];

	$update_result=mysqli_query($kidicite_config," UPDATE class_detail SET  class_detail_name='$c_detail_name',
    class_id='$class_id',
    c_id='$course_id',    
    class_description='$description',
    detail_status='$detail_status'
    WHERE class_detail_id='$c_detail_id'");
	if($update_result)
	{
	header('Location:view_class_detail.php');
	}
else
	{
	echo "No Data";
	}
?>