<?php

require("../kidicite_config.php");
$sql_course="select * from course";
$result1=mysqli_query($kidicite_config,$sql_course);
?>
<!Doctype html>

<html lang="en">

<head>
      <!--header-->
      <?php include("../assets/header_links/form_header.php");?>
    <!-- End of header -->
    <title>Kidicite &mdash; Course Page</title>
    
</head>
                    <?php
$class_id = "";                    
$class_name = "";
$class_detail = "";
$class_description = "";
$course_name="";
require("../kidicite_config.php");
$class_id =  isset($_GET['class_id'])? $_GET['class_id'] : "";
$class_name= isset($_GET['class_name'])? $_GET['class_name'] : ""; 
$class_detail = isset($_GET['class_detail'])? $_GET['class_detail'] : ""; 
$class_description= isset($_GET['class_description'])? $_GET['class_description'] : ""; 
$course_name = isset($_GET['course_name'])? $_GET['course_name'] : "";    
?>
<body>
    <div class="wrapper">
        <div class="auth-content">
            <div class="card">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <img class="brand" src="../assets/img/logo_transparent.png" width="120px" height="120px" alt="bootstraper logo">
                    </div>
                    <h6 class="mb-4 text-muted">Update Class Data</h6>
                    <form action="class_update_data.php" method="post">
                          <div class="mb-3 text-start">
                            
                            <input type="hidden" class="form-control"  name="class_id" value="<?php echo $class_id;?>">
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Class Name</label>
                            <input type="text" class="form-control" placeholder="Class Name" name="class_name" value="<?php echo $class_name;?>" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Is Detail </label>
                            <select name="class_detail" class="form-select"  required>
                            <option value="Open">Open</option>
                            <option value="Close">Close</option>
                            </select>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Calss Description </label>
                            <input type="text" class="form-control" placeholder="Class Description" name="class_desc" value="<?php echo $class_description;?>" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label for="name" class="form-label">Course Name </label>
                            <select name="course_id" class="form-select"  >
								<?php

									while ($rows = mysqli_fetch_array($result1)):;
								?>
									<option value="<?php echo $rows[0];?>"><?php echo $rows[2];?></option>

									<?php  endwhile; ?>
                                     </select>
                        </div>                         
                        <button class="btn btn-primary shadow-2 mb-4" name="enter">Upate Class</button>
                    </form>
                    <button class="btn btn-success shadow-2 mb-4"><a href="view_class.php">Back To View Class</a></button>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>