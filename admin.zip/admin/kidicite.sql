-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2021 at 08:46 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kidicite`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(35) NOT NULL,
  `admin_email` varchar(35) NOT NULL,
  `admin_password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'Khin Sandar Naing', 'khinsandar123@gmail.com', 'ksandar123#'),
(2, 'Kaw Da Nan', 'kdn456@gmail.com', 'kdnan456##');

-- --------------------------------------------------------

--
-- Table structure for table `batch_code`
--

CREATE TABLE `batch_code` (
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `class_detail_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `batch_code`
--

INSERT INTO `batch_code` (`batch_id`, `batch_name`, `start_date`, `end_date`, `class_detail_id`, `created_on`) VALUES
(1, 'batch2                                            ', '2021-11-23', '2021-12-23', 1, '2021-11-07 13:14:20'),
(2, 'Batch1', '2021-11-24', '2022-01-20', 1, '2021-11-14 13:40:36');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `class_detail` varchar(50) NOT NULL,
  `class_description` varchar(50) NOT NULL,
  `c_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `class_name`, `class_detail`, `class_description`, `c_id`, `created_on`) VALUES
(1, 'Japan batch 2                                     ', 'Open', 'Age - from 13 to 13                               ', 1, '2021-11-07 11:23:21'),
(2, 'Korea Batch 1', 'Open', 'Age - from 13 to 15', 3, '2021-11-14 13:39:33');

-- --------------------------------------------------------

--
-- Table structure for table `class_detail`
--

CREATE TABLE `class_detail` (
  `class_detail_id` int(11) NOT NULL,
  `class_detail_name` varchar(50) NOT NULL,
  `class_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `class_description` varchar(50) NOT NULL,
  `detail_status` varchar(50) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class_detail`
--

INSERT INTO `class_detail` (`class_detail_id`, `class_detail_name`, `class_id`, `c_id`, `class_description`, `detail_status`, `created_on`) VALUES
(1, 'Korea Basic batch 1                               ', 2, 3, 'Age - From 10 to 13                               ', 'Open', '2021-11-07 12:57:34');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `c_id` int(11) NOT NULL,
  `course_id` varchar(35) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `course_status` varchar(35) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`c_id`, `course_id`, `course_name`, `course_status`, `created_on`) VALUES
(1, 'Eng13', 'Foundation  ', 'open', '2021-11-07 08:26:50'),
(2, 'Jap1', 'Japanese', 'open', '2021-11-07 10:17:19'),
(3, 'Korea1 ', 'Korea ', 'open', '2021-11-14 13:38:17');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `s_id` int(11) NOT NULL,
  `staff_code` varchar(20) NOT NULL,
  `id` int(11) NOT NULL,
  `staff_name` varchar(30) NOT NULL,
  `letter_quotes` varchar(70) NOT NULL,
  `image` varchar(35) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`s_id`, `staff_code`, `id`, `staff_name`, `letter_quotes`, `image`, `created_on`) VALUES
(1, 'aca123', 1, 'Aye Aye', 'I do my best', 'alarm_clock_PNG88.png', '2021-11-20 06:31:31'),
(3, 'aca124', 1, 'Hla Hla', 'No pain, No Gain', '4438326.png', '2021-11-20 06:33:25'),
(4, 'aca125', 1, 'Myo Myo', 'You never fail until you stop trying', 'download.png', '2021-11-20 06:34:29');

-- --------------------------------------------------------

--
-- Table structure for table `staff_type`
--

CREATE TABLE `staff_type` (
  `id` int(11) NOT NULL,
  `staff_type_id` varchar(15) NOT NULL,
  `role` varchar(30) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_type`
--

INSERT INTO `staff_type` (`id`, `staff_type_id`, `role`, `created_on`) VALUES
(1, 'academic.02    ', 'English lecturer', '2021-11-20 05:35:12');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_code` varchar(20) NOT NULL,
  `student_name` varchar(40) NOT NULL,
  `student_phone` varchar(20) NOT NULL,
  `student_email` varchar(30) NOT NULL,
  `student_password` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `date_of_birth` date NOT NULL,
  `nrc_no` varchar(50) NOT NULL,
  `student_status` varchar(30) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_code`, `student_name`, `student_phone`, `student_email`, `student_password`, `gender`, `date_of_birth`, `nrc_no`, `student_status`, `created_on`) VALUES
(1, 'jp-21', 'Kyaw Kyaw', '09-793728273', 'kyaw1234@gmial.com', 'kyaw1234', 'Male', '2011-11-08', '9/Manama(N)0948934', 'Attending', '2021-11-07 13:31:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `batch_code`
--
ALTER TABLE `batch_code`
  ADD PRIMARY KEY (`batch_id`),
  ADD KEY `class_detail_id` (`class_detail_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `class_detail`
--
ALTER TABLE `class_detail`
  ADD PRIMARY KEY (`class_detail_id`),
  ADD KEY `class_id` (`class_id`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`s_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `staff_type`
--
ALTER TABLE `staff_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `batch_code`
--
ALTER TABLE `batch_code`
  MODIFY `batch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `class_detail`
--
ALTER TABLE `class_detail`
  MODIFY `class_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `staff_type`
--
ALTER TABLE `staff_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
